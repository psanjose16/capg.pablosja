export const environment = {
  production: false,
  apiUrl: 'http://localhost:8010/',
  securityApiURL: 'http://localhost:8091/',

};
