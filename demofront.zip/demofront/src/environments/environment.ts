export const environment = {
  production: true,
  apiUrl: '/api/catalogo/',
  securityApiURL: '/auth/',
};
